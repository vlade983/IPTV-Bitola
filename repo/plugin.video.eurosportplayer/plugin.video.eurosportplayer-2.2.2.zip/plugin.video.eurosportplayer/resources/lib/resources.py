# -*- coding: utf-8 -*-
            
def resources(string):
    if string == 'Today':
        return 30221
    elif string == 'Tomorrow':
        return 30222
    elif string == 'Monday':
        return 30223
    elif string == 'Tuesday':
        return 30224
    elif string == 'Wednesday':
        return 30225
    elif string == 'Thursday':
        return 30226
    elif string == 'Friday':
        return 30227
    elif string == 'Saturday':
        return 30228
    elif string == 'Sunday':
        return 30229
    else:
        return string
